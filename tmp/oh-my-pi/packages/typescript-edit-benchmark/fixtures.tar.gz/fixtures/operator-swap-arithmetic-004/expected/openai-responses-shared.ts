import type OpenAI from 'openai';
import type {
  ResponseFunctionToolCall,
  ResponseInput,
  ResponseInputContent,
  ResponseInputImage,
  ResponseInputText,
  ResponseOutputItem,
  ResponseOutputMessage,
  ResponseReasoningItem,
} from 'openai/resources/responses/responses';
import { calculateCost } from '../models';
import type {
  Api,
  AssistantMessage,
  ImageContent,
  Model,
  StopReason,
  TextContent,
  TextSignatureV1,
  ThinkingContent,
  ToolCall,
  ToolResultMessage,
} from '../types';
import { normalizeResponsesToolCallId } from '../utils';
import type { AssistantMessageEventStream } from '../utils/event-stream';
import { parseStreamingJson } from '../utils/json-parse';

export function encodeTextSignatureV1(id: string, phase?: TextSignatureV1['phase']): string {
  const payload: TextSignatureV1 = { v: 1, id };
  if (phase) payload.phase = phase;
  return JSON.stringify(payload);
}

export function parseTextSignature(
  signature: string | undefined,
): { id: string; phase?: TextSignatureV1['phase'] } | undefined {
  if (!signature) return undefined;
  if (signature.startsWith('{')) {
    try {
      const parsed = JSON.parse(signature) as Partial<TextSignatureV1>;
      if (parsed.v === 1 && typeof parsed.id === 'string') {
        if (parsed.phase === 'commentary' || parsed.phase === 'final_answer') {
          return { id: parsed.id, phase: parsed.phase };
        }
        return { id: parsed.id };
      }
    } catch {
      // Fall through to legacy plain-string handling.
    }
  }
  return { id: signature };
}

export function normalizeResponsesToolCallIdForTransform(
  id: string,
  model?: Model<Api>,
  source?: AssistantMessage,
): string {
  if (!id.includes('|')) return id;
  const isForeignToolCall =
    source != null &&
    model != null &&
    (source.provider !== model.provider || source.api !== model.api);
  if (isForeignToolCall) {
    const [callId, itemId] = id.split('|');
    const normalizeIdPart = (part: string): string => {
      const sanitized = part.replace(/[^a-zA-Z0-9_-]/g, '_');
      const truncated = sanitized.length > 64 ? sanitized.slice(0, 64) : sanitized;
      return truncated.replace(/_+$/, '');
    };
    const normalizedCallId = normalizeIdPart(callId);
    let normalizedItemId = `fc_${Bun.hash(itemId).toString(36)}`;
    if (normalizedItemId.length > 64) normalizedItemId = normalizedItemId.slice(0, 64);
    return `${normalizedCallId}|${normalizedItemId}`;
  }
  const normalized = normalizeResponsesToolCallId(id);
  return `${normalized.callId}|${normalized.itemId}`;
}

export function collectKnownCallIds(messages: ResponseInput): Set<string> {
  const knownCallIds = new Set<string>();
  for (const item of messages) {
    if (item.type === 'function_call' && typeof item.call_id === 'string') {
      knownCallIds.add(item.call_id);
    }
  }
  return knownCallIds;
}

export function convertResponsesInputContent(
  content: string | Array<TextContent | ImageContent>,
  supportsImages: boolean,
): ResponseInputContent[] | undefined {
  if (typeof content === 'string') {
    if (content.trim().length === 0) return undefined;
    return [{ type: 'input_text', text: content.toWellFormed() } satisfies ResponseInputText];
  }

  const normalizedContent = content
    .map((item): ResponseInputContent => {
      if (item.type === 'text') {
        return {
          type: 'input_text',
          text: item.text.toWellFormed(),
        } satisfies ResponseInputText;
      }
      return {
        type: 'input_image',
        detail: 'auto',
        image_url: `data:${item.mimeType};base64,${item.data}`,
      } satisfies ResponseInputImage;
    })
    .filter((item) => supportsImages || item.type !== 'input_image')
    .filter((item) => item.type !== 'input_text' || item.text.trim().length > 0);

  return normalizedContent.length > 0 ? normalizedContent : undefined;
}

export function convertResponsesAssistantMessage<TApi extends Api>(
  assistantMsg: AssistantMessage,
  model: Model<TApi>,
  msgIndex: number,
  knownCallIds: Set<string>,
  includeThinkingSignatures = true,
): ResponseInput {
  const outputItems: ResponseInput = [];
  const isDifferentModel =
    assistantMsg.model !== model.id &&
    assistantMsg.provider === model.provider &&
    assistantMsg.api === model.api;

  for (const block of assistantMsg.content) {
    if (block.type === 'thinking' && assistantMsg.stopReason !== 'error') {
      if (!includeThinkingSignatures) {
        continue;
      }
      if (block.thinkingSignature) {
        outputItems.push(JSON.parse(block.thinkingSignature) as ResponseReasoningItem);
      }
      continue;
    }

    if (block.type === 'text') {
      const parsedSignature = parseTextSignature(block.textSignature);
      let msgId = parsedSignature?.id;
      if (!msgId) {
        msgId = `msg_${msgIndex}`;
      } else if (msgId.length > 64) {
        msgId = `msg_${Bun.hash.xxHash64(msgId).toString(36)}`;
      }
      outputItems.push({
        type: 'message',
        role: 'assistant',
        content: [{ type: 'output_text', text: block.text.toWellFormed(), annotations: [] }],
        status: 'completed',
        id: msgId,
        phase: parsedSignature?.phase,
      } satisfies ResponseOutputMessage);
      continue;
    }

    if (block.type !== 'toolCall') {
      continue;
    }

    const normalized = normalizeResponsesToolCallId(block.id);
    let itemId: string | undefined = normalized.itemId;
    if (isDifferentModel && (itemId?.startsWith('fc_') || itemId?.startsWith('fcr_'))) {
      itemId = undefined;
    }
    knownCallIds.add(normalized.callId);
    outputItems.push({
      type: 'function_call',
      id: itemId,
      call_id: normalized.callId,
      name: block.name,
      arguments: JSON.stringify(block.arguments),
    });
  }

  return outputItems;
}

export function appendResponsesToolResultMessages<TApi extends Api>(
  messages: ResponseInput,
  toolResult: ToolResultMessage,
  model: Model<TApi>,
  strictResponsesPairing: boolean,
  knownCallIds: ReadonlySet<string>,
): void {
  const textResult = toolResult.content
    .filter((block): block is TextContent => block.type === 'text')
    .map((block) => block.text)
    .join('\n');
  const hasImages = toolResult.content.some(
    (block): block is ImageContent => block.type === 'image',
  );
  const normalized = normalizeResponsesToolCallId(toolResult.toolCallId);
  if (strictResponsesPairing && !knownCallIds.has(normalized.callId)) {
    return;
  }

  messages.push({
    type: 'function_call_output',
    call_id: normalized.callId,
    output: (textResult.length > 0 ? textResult : '(see attached image)').toWellFormed(),
  });

  if (!hasImages || !model.input.includes('image')) {
    return;
  }

  const contentParts: ResponseInputContent[] = [
    { type: 'input_text', text: 'Attached image(s) from tool result:' } satisfies ResponseInputText,
  ];
  for (const block of toolResult.content) {
    if (block.type === 'image') {
      contentParts.push({
        type: 'input_image',
        detail: 'auto',
        image_url: `data:${block.mimeType};base64,${block.data}`,
      } satisfies ResponseInputImage);
    }
  }
  messages.push({ role: 'user', content: contentParts });
}

export interface ProcessResponsesStreamOptions {
  onFirstToken?: () => void;
  onOutputItemDone?: (item: ResponseOutputItem) => void;
}

export async function processResponsesStream<TApi extends Api>(
  openaiStream: AsyncIterable<OpenAI.Responses.ResponseStreamEvent>,
  output: AssistantMessage,
  stream: AssistantMessageEventStream,
  model: Model<TApi>,
  options?: ProcessResponsesStreamOptions,
): Promise<void> {
  let currentItem: ResponseReasoningItem | ResponseOutputMessage | ResponseFunctionToolCall | null =
    null;
  let currentBlock: ThinkingContent | TextContent | (ToolCall & { partialJson: string }) | null =
    null;
  const blocks = output.content;
  const blockIndex = () => blocks.length - 1;
  let sawFirstToken = false;

  for await (const event of openaiStream) {
    if (event.type === 'response.created') {
      output.responseId = event.response.id;
    } else if (event.type === 'response.output_item.added') {
      if (!sawFirstToken) {
        sawFirstToken = true;
        options?.onFirstToken?.();
      }
      const item = event.item;
      if (item.type === 'reasoning') {
        currentItem = item;
        currentBlock = { type: 'thinking', thinking: '' };
        output.content.push(currentBlock);
        stream.push({ type: 'thinking_start', contentIndex: blockIndex(), partial: output });
      } else if (item.type === 'message') {
        currentItem = item;
        currentBlock = { type: 'text', text: '' };
        output.content.push(currentBlock);
        stream.push({ type: 'text_start', contentIndex: blockIndex(), partial: output });
      } else if (item.type === 'function_call') {
        currentItem = item;
        currentBlock = {
          type: 'toolCall',
          id: `${item.call_id}|${item.id}`,
          name: item.name,
          arguments: {},
          partialJson: item.arguments || '',
        };
        output.content.push(currentBlock);
        stream.push({ type: 'toolcall_start', contentIndex: blockIndex(), partial: output });
      }
    } else if (event.type === 'response.reasoning_summary_part.added') {
      if (currentItem?.type === 'reasoning') {
        currentItem.summary = currentItem.summary || [];
        currentItem.summary.push(event.part);
      }
    } else if (event.type === 'response.reasoning_summary_text.delta') {
      if (currentItem?.type === 'reasoning' && currentBlock?.type === 'thinking') {
        currentItem.summary = currentItem.summary || [];
        const lastPart = currentItem.summary[currentItem.summary.length - 1];
        if (lastPart) {
          currentBlock.thinking += event.delta;
          lastPart.text += event.delta;
          stream.push({
            type: 'thinking_delta',
            contentIndex: blockIndex(),
            delta: event.delta,
            partial: output,
          });
        }
      }
    } else if (event.type === 'response.reasoning_summary_part.done') {
      if (currentItem?.type === 'reasoning' && currentBlock?.type === 'thinking') {
        currentItem.summary = currentItem.summary || [];
        const lastPart = currentItem.summary[currentItem.summary.length - 1];
        if (lastPart) {
          currentBlock.thinking += '\n\n';
          lastPart.text += '\n\n';
          stream.push({
            type: 'thinking_delta',
            contentIndex: blockIndex(),
            delta: '\n\n',
            partial: output,
          });
        }
      }
    } else if (event.type === 'response.content_part.added') {
      if (currentItem?.type === 'message') {
        currentItem.content = currentItem.content || [];
        if (event.part.type === 'output_text' || event.part.type === 'refusal') {
          currentItem.content.push(event.part);
        }
      }
    } else if (event.type === 'response.output_text.delta') {
      if (currentItem?.type === 'message' && currentBlock?.type === 'text') {
        const lastPart = currentItem.content?.[currentItem.content.length - 1];
        if (lastPart?.type === 'output_text') {
          currentBlock.text += event.delta;
          lastPart.text += event.delta;
          stream.push({
            type: 'text_delta',
            contentIndex: blockIndex(),
            delta: event.delta,
            partial: output,
          });
        }
      }
    } else if (event.type === 'response.refusal.delta') {
      if (currentItem?.type === 'message' && currentBlock?.type === 'text') {
        const lastPart = currentItem.content?.[currentItem.content.length - 1];
        if (lastPart?.type === 'refusal') {
          currentBlock.text += event.delta;
          lastPart.refusal += event.delta;
          stream.push({
            type: 'text_delta',
            contentIndex: blockIndex(),
            delta: event.delta,
            partial: output,
          });
        }
      }
    } else if (event.type === 'response.function_call_arguments.delta') {
      if (currentItem?.type === 'function_call' && currentBlock?.type === 'toolCall') {
        currentBlock.partialJson += event.delta;
        currentBlock.arguments = parseStreamingJson(currentBlock.partialJson);
        stream.push({
          type: 'toolcall_delta',
          contentIndex: blockIndex(),
          delta: event.delta,
          partial: output,
        });
      }
    } else if (event.type === 'response.function_call_arguments.done') {
      if (currentItem?.type === 'function_call' && currentBlock?.type === 'toolCall') {
        currentBlock.partialJson = event.arguments;
        currentBlock.arguments = parseStreamingJson(currentBlock.partialJson);
      }
    } else if (event.type === 'response.output_item.done') {
      const item = event.item;
      options?.onOutputItemDone?.(item);
      if (item.type === 'reasoning' && currentBlock?.type === 'thinking') {
        currentBlock.thinking = item.summary?.map((part) => part.text).join('\n\n') || '';
        currentBlock.thinkingSignature = JSON.stringify(item);
        stream.push({
          type: 'thinking_end',
          contentIndex: blockIndex(),
          content: currentBlock.thinking,
          partial: output,
        });
        currentBlock = null;
      } else if (item.type === 'message' && currentBlock?.type === 'text') {
        currentBlock.text = item.content
          .map((part) => (part.type === 'output_text' ? (part.text ?? '') : (part.refusal ?? '')))
          .join('');
        currentBlock.textSignature = encodeTextSignatureV1(item.id, item.phase ?? undefined);
        stream.push({
          type: 'text_end',
          contentIndex: blockIndex(),
          content: currentBlock.text,
          partial: output,
        });
        currentBlock = null;
      } else if (item.type === 'function_call') {
        const args =
          currentBlock?.type === 'toolCall' && currentBlock.partialJson
            ? parseStreamingJson(currentBlock.partialJson)
            : parseStreamingJson(item.arguments || '{}');
        const toolCall: ToolCall = {
          type: 'toolCall',
          id: `${item.call_id}|${item.id}`,
          name: item.name,
          arguments: args,
        };
        currentBlock = null;
        stream.push({
          type: 'toolcall_end',
          contentIndex: blockIndex(),
          toolCall,
          partial: output,
        });
      }
    } else if (event.type === 'response.completed') {
      const response = event.response;
      if (response?.id) {
        output.responseId = response.id;
      }
      if (response?.usage) {
        const cachedTokens = response.usage.input_tokens_details?.cached_tokens || 0;
        output.usage = {
          input: (response.usage.input_tokens || 0) - cachedTokens,
          output: response.usage.output_tokens || 0,
          cacheRead: cachedTokens,
          cacheWrite: 0,
          totalTokens: response.usage.total_tokens || 0,
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
        };
      }
      calculateCost(model, output.usage);
      output.stopReason = mapOpenAIResponsesStopReason(response?.status);
      if (
        output.content.some((block) => block.type === 'toolCall') &&
        output.stopReason === 'stop'
      ) {
        output.stopReason = 'toolUse';
      }
    } else if (event.type === 'error') {
      throw new Error(`Error Code ${event.code}: ${event.message}` || 'Unknown error');
    } else if (event.type === 'response.failed') {
      const error = event.response?.error;
      const details = event.response?.incomplete_details;
      const message = error
        ? `${error.code || 'unknown'}: ${error.message || 'no message'}`
        : details?.reason
          ? `incomplete: ${details.reason}`
          : 'Unknown error (no error details in response)';
      throw new Error(message);
    }
  }
}

export function mapOpenAIResponsesStopReason(
  status: OpenAI.Responses.ResponseStatus | undefined,
): StopReason {
  if (!status) return 'stop';
  switch (status) {
    case 'completed':
      return 'stop';
    case 'incomplete':
      return 'length';
    case 'failed':
    case 'cancelled':
      return 'error';
    case 'in_progress':
    case 'queued':
      return 'stop';
    default: {
      const exhaustive: never = status;
      throw new Error(`Unhandled stop reason: ${exhaustive}`);
    }
  }
}
